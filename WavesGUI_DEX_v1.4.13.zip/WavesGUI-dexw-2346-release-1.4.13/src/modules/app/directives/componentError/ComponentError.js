(function () {
    'use strict';

    angular.module('app').component('wComponentError', {
        templateUrl: 'modules/app/directives/componentError/componentError.html'
    });
})();
