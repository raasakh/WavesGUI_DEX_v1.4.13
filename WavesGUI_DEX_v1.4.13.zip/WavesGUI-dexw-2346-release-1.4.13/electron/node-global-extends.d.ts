///<reference path="interface.d.ts"/>


declare module NodeJS {
    interface Global {
        main: IMain;
    }
}
